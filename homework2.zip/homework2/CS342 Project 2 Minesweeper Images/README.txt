Daniel Hajnos

Original image from http://www.spriters-resource.com/pc_computer/minesweeper/sheet/19849/

Spliced up the sprite sheet in GIMP 2.8